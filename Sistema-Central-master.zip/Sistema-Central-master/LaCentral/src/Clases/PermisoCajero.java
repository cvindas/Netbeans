/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Alonso
 */
public class PermisoCajero 
{
    
}
