Sistema-Cental
==============

Sistema de Inventario realizado en Java e Hibernate con conexion a base de datos MySQL

![Image](https://raw.githubusercontent.com/AlonsoCampos/Sistema-Central/master/Sistema.png)




![Image](https://raw.githubusercontent.com/AlonsoCampos/Sistema-Central/master/Negocio.png)
